import asyncio
import os
from dotenv import load_dotenv

os.environ['DISCORD_SKIP_CTYPES'] = '1'

# Load environment variables from .env file
load_dotenv()

import discord

# ============ CONFIGURATION ============
TOKEN = os.getenv('DISCORD_TOKEN')
SOURCE_CHANNEL_ID = 1376019152103280751
DEST_CHANNEL_ID = 1479870819588112404
# =======================================

class MessageForwarder(discord.Client):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        intents.members = True
        super().__init__(intents=intents, chunk_guilds_at_startup=True)
        self.processed_history = False
        self.forwarded_ids = set()
        
    async def on_ready(self):
        print(f'✅ Logged in as {self.user.name} (ID: {self.user.id})')
        print(f'🌐 Connected to {len(self.guilds)} servers')
        print('⏳ Waiting for channels to cache...')
        
        # Wait for internal cache to populate
        await asyncio.sleep(3)
        
        # Try to get channels from cache first
        source_channel = self.get_channel(SOURCE_CHANNEL_ID)
        dest_channel = self.get_channel(DEST_CHANNEL_ID)
        
        # If not cached, fetch them directly from API
        if not source_channel:
            try:
                source_channel = await self.fetch_channel(SOURCE_CHANNEL_ID)
            except Exception as e:
                print(f'❌ Could not find source channel: {e}')
                return
                
        if not dest_channel:
            try:
                dest_channel = await self.fetch_channel(DEST_CHANNEL_ID)
            except Exception as e:
                print(f'❌ Could not find destination channel: {e}')
                return
        
        print(f'📡 Source: #{source_channel.name}')
        print(f'📡 Destination: #{dest_channel.name}')
        print('=' * 50)
        
        # Forward all old messages first
        await self.forward_history(source_channel, dest_channel)
        
        # Start listening for new messages
        self.processed_history = True
        print('✅ Historical messages forwarded! Now listening for new messages...')
    
    def is_unusual_message(self, message):
        """Check if message is unusual (bot, system, etc.) and should be filtered"""
        # Skip bot messages
        if message.author.bot:
            return True
        # Skip system messages
        if message.type != discord.MessageType.default:
            return True
        # Skip messages with no content and no attachments
        if not message.content and not message.attachments:
            return True
        return False
        
    async def forward_history(self, source_channel, dest_channel):
        print('📚 Fetching message history (oldest first)...')
        
        message_count = 0
        # limit=None gets ALL messages, oldest_first=True goes from bottom to top
        async for message in source_channel.history(limit=None, oldest_first=True):
            # Skip unusual messages
            if self.is_unusual_message(message):
                continue
                
            await self.forward_single_message(message, dest_channel)
            self.forwarded_ids.add(message.id)
            message_count += 1
            
            # Print progress every 10 messages
            if message_count % 10 == 0:
                print(f'   Forwarded {message_count} messages...')
            
            # Sleep to avoid Discord rate limits
            await asyncio.sleep(0.8)
        
        print(f'✅ Total historical messages forwarded: {message_count}')
        
    async def forward_single_message(self, message, dest_channel):
        try:
            # Get author details
            author_name = message.author.display_name
            author_id = message.author.id
            
            # Build message content
            content_lines = []
            
            # Add author header
            content_lines.append(f"**{author_name}** (`{author_id}`)")
            
            # Add message text and remove mentions
            if message.content:
                # Replace mentions with their names to avoid pings
                msg_content = message.content
                # Remove @everyone and @here
                msg_content = msg_content.replace("@everyone", "")
                msg_content = msg_content.replace("@here", "")
                # Remove user mentions
                msg_content = msg_content.replace("<@", r"\<@")
                msg_content = msg_content.replace("<@!", r"\<@!")
                # Remove role mentions
                msg_content = msg_content.replace("<@&", r"\<@&")
                # Remove channel mentions
                msg_content = msg_content.replace("<#", r"\<#")
                # Remove sammy() if it appears
                msg_content = msg_content.replace("**Sammy** (`303327056274653197`)", "")
                content_lines.append(msg_content)
            
            # Add attachment links if any
            if message.attachments:
                for att in message.attachments:
                    content_lines.append(f"[{att.filename}]({att.url})")
            
            # Combine all lines
            final_content = "\n".join(content_lines)
            
            # Send the message
            await dest_channel.send(content=final_content)
            
        except discord.HTTPException as e:
            error_str = str(e).lower()
            if 'rate limit' in error_str:
                # Extract retry_after time if possible, default to 5 seconds
                retry_after = 5
                if 'retry_after: ' in error_str:
                    try:
                        retry_after = int(error_str.split('retry_after: ')[1].split('}')[0])
                    except Exception:
                        pass
                print(f'⏳ Rate limited, waiting {retry_after}s...')
                await asyncio.sleep(retry_after)
                # Retry sending the failed message
                await self.forward_single_message(message, dest_channel)
            else:
                print(f'❌ HTTP Error on msg {message.id}: {e}')
        except Exception as e:
            print(f'❌ Error forwarding message {message.id}: {e}')
            
    async def on_message(self, message):
        # Ignore messages sent by our own account
        if message.author.id == self.user.id:
            return
            
        # Only forward if it's from the source channel AND we finished loading history
        if message.channel.id == SOURCE_CHANNEL_ID and self.processed_history:
            # Skip unusual messages
            if self.is_unusual_message(message):
                return
                
            if message.id not in self.forwarded_ids:
                dest_channel = self.get_channel(DEST_CHANNEL_ID)
                if not dest_channel:
                    try:
                        dest_channel = await self.fetch_channel(DEST_CHANNEL_ID)
                    except Exception:
                        return
                
                await self.forward_single_message(message, dest_channel)
                print(f'📨 Forwarded new message from {message.author.name}')

# Run the client
if __name__ == "__main__":
    print('🚀 Starting Message Forwarder...')
    print('=' * 50)
    
    if not TOKEN:
        print('❌ ERROR: DISCORD_TOKEN environment variable is not set!')
        print('Add DISCORD_TOKEN=<your_token> in Pterodactyl startup variables')
        exit(1)
    
    client = MessageForwarder()
    client.run(TOKEN)